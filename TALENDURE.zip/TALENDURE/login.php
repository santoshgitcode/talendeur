<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<title>Talendure</title>
	<link rel="stylesheet" type="text/css" href="style/style1.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>
<body>
	<div class="main_container">
		<div class="top_nav">
			<div class="logo">
				<img src="image/logo.png">

			</div>
			
				<ul class="top_navigation">
					<li><a href="#">OUR STORY</a></li>
					<li><a href="#">INSIGHTS</a></li>
					<li><a href="#">GET IN TOUCH</a></li>
					<li><a href="#"></a><i class="fa fa-user-circle" aria-hidden="true"></i></li>
				</ul>
		</div>

		<div class="container login_container ">
			<div class="content_register">
				<h3>Login to your Account</h3>
				<p>Do not Have an Account. Create a <a href="register.php">Account</a></p>
			</div>
				<form id="login_form" name="login_form">
              <div class="form-row">
                          <div class="form-group">
                            <label for="degreee">Email<span class="mandetory">*</span></label>
                            <input type="email" class="form-control login_input" name="email">
                          </div>
                        </div>

              <div class="form-row">
                          <div class="form-group">
                            <label for="degreee">Password<span class="mandetory">*</span></label>
                            <input type="password" class="form-control login_input" name="password">
                          </div>
                        </div> 
                        

            <button type="button" class="btn btn-warning" onclick="login_data();" data-dismiss="modal">Register</button>
          </form>
		</div>
	</div>
	<script type="text/javascript">
		function login_data(){
			var formData = new FormData(login_form);
      formData.append('action','login_form_data');
         $.ajax({
           url:'tprocess.php',
           type:'POST',
           data:formData,
           contentType:false,
           processData:false,
           success:function(result){
             console.log(result);

             if (result == "success") {
               alert("Login Successful");
               window.location.replace("home.php");
             }

        // location.reload();
      }
     })
		}
	</script>
</body>
</html>