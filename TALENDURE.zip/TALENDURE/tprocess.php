<?php
  include 'connection.php';

  session_start();
  if (isset($_POST['action'])) {
  	if ($_POST['action'] == "register_form_data") {
  		$fanme = $_POST['fname'];
  		$lname = $_POST['lname'];
  		$email = $_POST['email'];
  		$mobile = $_POST['mobile'];
  		$password = $_POST['password'];
  		$cpassword = $_POST['cpassword'];

  		// echo $fanme." ".$lname." ".$email." ".$mobile." ".$password." ".$cpassword;

  		$queryemail = "select * from register where (email = '$email')";
		$exe = mysqli_query($con,$queryemail);
		$rows = mysqli_num_rows($exe);
		 // echo "$rows";
		 // exit();
         if ($rows > 0) {
         	echo "User Already Registered";
         }
         else{
		$query = "insert into register (fname,lname,email,mobile,pass,cpass) values ('$fanme','$lname','$email','$mobile','$password','$cpassword')";
		$res = mysqli_query($con,$query);
		if ($res) {
			echo "success";
		}
		else{
			echo "no";
		}
	}
  	}

  	if ($_POST['action'] == "login_form_data") {
  		

  		$email = $_POST["email"];
	    $password = $_POST["password"];


	    $emailquery = "select * from register where email = '$email'";

	$emailrun = mysqli_query($con,$emailquery);

	$rowdata = mysqli_fetch_array($emailrun);
	$existpass = $rowdata['pass'];
	$existemail = $rowdata['email'];

	$_SESSION["id"] = $rowdata['id'];

	 $_SESSION["fname"] = $rowdata['fname'];

	 if (($email === $existemail) && ($password === $existpass)) {
	 	

	 	echo "success";
	 }
	 else{
	 	echo "fiailed";
	 }




  	}


  	if ($_POST['action'] == "logout") {
  		session_destroy();
		echo "success";
  	}

  	// end of isset
  }
?>