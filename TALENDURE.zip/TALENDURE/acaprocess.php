<?php
include 'connection.php';
if ($_POST['type'] == "") {
	$sql = "select * from edulevel";
$qrun = mysqli_query($con,$sql);
$str = "";
 


 while ($row = mysqli_fetch_assoc($qrun)) {
  	$str .= "<option value ='{$row['edu_id']}'>{$row['edu_level']}</option>";
  }
}
elseif($_POST['type'] == "feild_study"){
	$sql = "select * from feildofstudy";
$qrun = mysqli_query($con,$sql);
$str = "";
 


 while ($row = mysqli_fetch_assoc($qrun)) {
  	$str .= "<option value ='{$row['feild_id']}'>{$row['feild_name']}</option>";
  }
}

elseif($_POST['type'] == "degree"){
	$id = $_POST['id'];
	$sql = "select * from degreee where feild_id = {$id}";
$qrun = mysqli_query($con,$sql);
$str = "";
 


 while ($row = mysqli_fetch_assoc($qrun)) {
  	$str .= "<option value ='{$row['deg_id']}'>{$row['deg_name']}</option>";
  }
}



elseif($_POST['type'] == "university"){
  $id = $_POST['id'];
  $sql = "select * from university where degre_id = {$id}";
$qrun = mysqli_query($con,$sql);
$str = "";
 


 while ($row = mysqli_fetch_assoc($qrun)) {
    $str .= "<option value ='{$row['uni_id']}'>{$row['uni_name']}</option>";
  }
}


  echo $str;


  
?>