<?php
include 'connection.php';

  if (isset($_POST['action'])) {
    if($_POST['action'] == "academic_form_data"){
       $edu_level = $_POST['edu_level'];
       $field_study = $_POST['field_study'];
       $degree = $_POST['degree'];
       $university = $_POST['university'];
       $form_month = $_POST['form_month'];
       $form_year = $_POST['form_year'];
       $to_month = $_POST['to_month'];
       $to_year = $_POST['to_year'];


       // echo  $edu_level." ".$field_study." ".$degree." ".$university." ".$form_month." ".$form_year." ".$to_month." ".$to_year;

       $aca_insert_query = "insert into academic (edu_level,field_study,degree,university,form_month,form_year,to_month,to_year) values ('$edu_level','$field_study','$degree','$university','$form_month','$form_year','$to_month','$to_year')";

       $aca_query_run = mysqli_query($con,$aca_insert_query);
    }
  }
?>