<!DOCTYPE html>
<html lang="en">
<head>
  <title>Index</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Education Level</h2>
  <form name="edu_level" id="edu_level">
    <div class="form-group">
      <label for="education">Education Level:</label>
      <select id="education" name="education" class="form-control">
      	<option value="school">School</option>
      	<option value="college">College</option>
      	<option value="university">University</option>
      </select>
    </div>
    <div class="form-group">
      <label>Value</label>
      <select id="edu_value" name="edu_value" class="form-control">
      	<option value="1">1</option>
      	<option value="3">3</option>
      	<option value="5">5</option>
      </select>
    </div>
    <button type="button" class="btn btn-primary" onclick="send_data();">Submit</button>
  </form>
</div>

<div class="container mt-5">
  <h2>Feild Of Study</h2>
  <form name="feild_of_study" id="feild_of_study">
    <div class="form-group">
      <label for="feildname">Feild Name:</label>
      <select id="feildname" name="feildname" class="form-control">
      	<option value="arts">Arts</option>
      	<option value="commerce">Commerce</option>
      	<option value="science">Science</option>
      </select>
    </div>
    <div class="form-group">
      <label>Value</label>
      <select id="edu_value" name="feild_value" class="form-control">
      	<option value="1">1</option>
      	<option value="2">2</option>
      	<option value="3">3</option>
      </select>
    </div>
    <button type="button" class="btn btn-primary" onclick="send_feild_data();">Submit</button>
  </form>
</div>


<div class="container mt-5">
  <h2>Degree</h2>
  <form name="degree" id="degree">
    <div class="form-group">
      <label for="degreeName">Degree Name:</label>
      <select id="degreeName" name="degreeName" class="form-control">
      	<option value="ba">BA</option>
      	<option value="Btech">Btech</option>
      	<option value="Bsc">Bsc</option>
      	<option value="Bcom">Bcom</option>
      </select>
    </div>
    <div class="form-group">
      <label>Feild Of Study:</label>
      <select id="feild_id" name="feild_id" class="form-control">
      	<option value="1">Arts</option>
      	<option value="2">Science</option>
      	<option value="3">Commerce</option>
      </select>
    </div>
    <div class="form-group">
      <label>Degree Value</label>
      <select id="deg_value" name="deg_value" class="form-control">
      	<option value="0.5">0.5</option>
      	<option value="0.75">0.75</option>
      	<option value="1">1</option>
      </select>
    </div>
    <button type="button" class="btn btn-primary" onclick="send_degree_data();">Submit</button>
  </form>
</div>


<div class="container mt-5">
  <h2>College And University</h2>
  <form name="university" id="university">
    <div class="form-group">
      <label for="university_name">Degree Name:</label>
      <select id="university_name" name="university_name" class="form-control">
        <option value="IIT">IIT</option>
        <option value="IIIT">IIIT</option>
        <option value="BJB">BJB</option>
        <option value="AICTE">AICTE</option>
      </select>
    </div>
    <div class="form-group">
      <label>DEGREE:</label>
      <select id="deg_id" name="deg_id" class="form-control">
        <option value="1">BA</option>
        <option value="2">BTECH</option>
        <option value="3">BSC</option>
        <option value="3">BCOM</option>
      </select>
    </div>
    <div class="form-group">
      <label>Degree Value</label>
      <select id="uni_value" name="uni_value" class="form-control">
        <option value="0.5">0.5</option>
        <option value="0.75">0.75</option>
        <option value="1">1</option>
      </select>
    </div>
    <button type="button" class="btn btn-primary" onclick="send_university_data();">Submit</button>
  </form>
</div>


<script type="text/javascript">
  function send_data(){
    var formData = new FormData(degree);///edu_level refer to name of the form
    formData.append('action','edu_level_data');
     console.log(formData);

     $.ajax({
      url:'process.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })

  }

  function send_feild_data(){
    var formData = new FormData(feild_of_study);///edu_level refer to name of the form
    formData.append('action','feild_study_data');
     console.log(formData);

     $.ajax({
      url:'process.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })

  }



  function send_degree_data(){
    var formData = new FormData(degree);///edu_level refer to name of the form
    formData.append('action','degree_data');
     console.log(formData);

     $.ajax({
      url:'process.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })

  }


  function send_university_data(){
    var formData = new FormData(university);///edu_level refer to name of the form
    formData.append('action','uni_data');
     console.log(formData);

     $.ajax({
      url:'process.php',
      type:'POST',
      data:formData,
      contentType:false,
      processData:false,
      success:function(result){
        console.log(result);

        // location.reload();
      }
     })

  }
</script>
</body>
</html>
